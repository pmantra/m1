import time
from datetime import datetime, timezone, timedelta

import unittest
import mock

from snowflake.snowflake import (
    TIMESTAMP_LENGTH,
    NONCE_LENGTH,
    EPOCH,
    generate,
    parse,
    to_datetime,
    from_datetime,
    to_base36,
    from_base36,
    to_base57,
    from_base57,
    to_base62,
    from_base62,
    to_base64,
    from_base64,
    lower_bound_for_datetime,
    upper_bound_for_datetime,
    make_epoch_timestamp,
)


class FlakeTestCase(unittest.TestCase):

    def test_generate(self):
        value = generate()
        self.assertIsNotNone(value)
        self.assertNotEqual(0, value)

    def test_generate_overflow(self):
        value = make_epoch_timestamp()
        value <<= 43 - value.bit_length()
        with self.assertRaises(ValueError):
            generate(value)

    def test_generate_with_timestamp(self):
        expected = make_epoch_timestamp()
        value = generate(expected)

        self.assertEqual(expected, value >> NONCE_LENGTH)

    def test_make_epoch_timestamp(self):
        value = make_epoch_timestamp()
        self.assertIsNotNone(value)
        self.assertNotEqual(0, value)

    def test_make_epoch_timestamp_bogus_posix_timestamp(self):
        with self.assertRaises(ValueError):
            make_epoch_timestamp(EPOCH - 5000)

    def test_make_epoch_timestamp_mock(self):
        now = time.time()
        with mock.patch('time.time', return_value=now):
            value = make_epoch_timestamp()
            expected = int(round((now * 1000))) - (EPOCH * 1000)
            self.assertEqual(expected, value)

    def test_parse(self):
        ts = make_epoch_timestamp()
        flake = generate(ts)

        timestamp_part, nonce_part = parse(flake)
        self.assertEqual(ts, timestamp_part)
        self.assertNotEqual(0, nonce_part)

    def test_parser_preconditions(self):
        with self.assertRaises(ValueError):
            parse(None)
        with self.assertRaises(ValueError):
            parse(-1)

    def test_to_datetime(self):
        ts = make_epoch_timestamp()
        flake = generate(ts)
        utc_time = to_datetime(flake)
        delta = timedelta(milliseconds=ts)
        dt = datetime.fromtimestamp(EPOCH, tz=timezone.utc) + delta
        self.assertEqual(utc_time, dt)

    def test_from_datetime(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0, timezone.utc)
        flake = from_datetime(dt)
        self.assertEqual(31536000000, flake >> NONCE_LENGTH)

    def test_from_datetime_no_timezone(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0)
        with self.assertRaises(ValueError):
            from_datetime(dt)

    def test_from_datetime_bogus_timezone(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0, timezone(timedelta(hours=5)))
        with self.assertRaises(ValueError):
            from_datetime(dt)

    def test_from_datetime_bogus_datetime(self):
        dt = datetime(2000, 1, 1, 0, 0, 0, 0, timezone.utc)
        with self.assertRaises(ValueError):
            from_datetime(dt)

    def test_to_base36(self):
        value = 551943644444245651
        encoded = to_base36(value)
        self.assertEqual('46ynoxtvietv', encoded)

    def test_from_base36(self):
        value = '46ynoxtvietv'
        flake = from_base36(value)
        self.assertEqual(551943644444245651, flake)

    def test_from_mixed_case_base36(self):
        value = '46yNoxTVIetv'
        flake = from_base36(value)
        self.assertEqual(551943644444245651, flake)

    def test_to_hyphenated_base36(self):
        value = 551943644444245651
        encoded = to_base36(value, True)
        self.assertEqual('46yn-oxtv-ietv', encoded)

    def test_from_hyphenated_base36(self):
        value = '46yn-oxtv-ietv'
        flake = from_base36(value)
        self.assertEqual(551943644444245651, flake)

    def test_from_hyphenated_mixed_case_base36(self):
        value = '46yn-OXTV-ietv'
        flake = from_base36(value)
        self.assertEqual(551943644444245651, flake)

    def test_to_base57(self):
        value = 551943644444245651
        encoded = to_base57(value)
        self.assertEqual('1WtHvLwDn9r', encoded)

    def test_from_base57(self):
        value = '1WtHvLwDn9r'
        flake = from_base57(value)
        self.assertEqual(551943644444245651, flake)

    def test_to_base62(self):
        value = 551943644444245651
        encoded = to_base62(value)
        self.assertEqual('eluHNaQFtr', encoded)

    def test_from_base62(self):
        value = 'eluHNaQFtr'
        flake = from_base62(value)
        self.assertEqual(551943644444245651, flake)

    def test_to_base64(self):
        value = 551943644444245651
        encoded = to_base64(value)
        self.assertEqual('B6jl0f8iPpM', encoded)

    def test_from_base64(self):
        value = 'B6jl0f8iPpM'
        flake = from_base64(value)
        self.assertEqual(551943644444245651, flake)

    def test_from_base64_small(self):
        value = 'AfQ'
        flake = from_base64(value)
        self.assertEqual(500, flake)

    def test_lower_bound_for_datetime(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0, timezone.utc)
        self.assertEqual(132271570944000000, lower_bound_for_datetime(dt))

    def test_lower_bound_for_datetime_no_timezone(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0)
        with self.assertRaises(ValueError):
            lower_bound_for_datetime(dt)

    def test_lower_bound_for_datetime_bogus_timezone(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0, timezone(timedelta(hours=5)))
        with self.assertRaises(ValueError):
            lower_bound_for_datetime(dt)

    def test_lower_bound_for_datetime_bogus_datetime(self):
        dt = datetime(2000, 1, 1, 0, 0, 0, 0, timezone.utc)
        with self.assertRaises(ValueError):
            lower_bound_for_datetime(dt)

    def test_upper_bound_for_datetime(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0, timezone.utc)
        self.assertEqual(132271570948194303, upper_bound_for_datetime(dt))

    def test_upper_bound_for_datetime_no_timezone(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0)
        with self.assertRaises(ValueError):
            upper_bound_for_datetime(dt)

    def test_upper_bound_for_datetime_bogus_timezone(self):
        dt = datetime(2015, 1, 1, 0, 0, 0, 0, timezone(timedelta(hours=5)))
        with self.assertRaises(ValueError):
            upper_bound_for_datetime(dt)

    def test_upper_bound_for_datetime_bogus_datetime(self):
        dt = datetime(2000, 1, 1, 0, 0, 0, 0, timezone.utc)
        with self.assertRaises(ValueError):
            upper_bound_for_datetime(dt)
