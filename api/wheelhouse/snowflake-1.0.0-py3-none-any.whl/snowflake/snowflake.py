import base64
from datetime import datetime, timedelta, timezone
import secrets
import string
import struct
import time


TIMESTAMP_LENGTH = 42
TIMESTAMP_MASK = 0xFFFFFFFFFFFFFFFF << TIMESTAMP_LENGTH

NONCE_LENGTH = 22
NONCE_MAX = 0xFFFFFFFFFFFFFFFF >> TIMESTAMP_LENGTH

EPOCH = 1388534400 # seconds from UNIX UTC epoch until 2014-01-01T00:00:00+00:00

BASE36_ALPHABET = string.digits + string.ascii_lowercase
BASE57_ALPHABET = "0123456789ABCDEFGHJKLMNPQRSTVWXYZabcdefghijkmnopqrstvwxyz"
BASE62_ALPHABET = string.digits + string.ascii_uppercase + string.ascii_lowercase


def generate(epoch_timestamp=None):
    """
    Generate a new 64-bit k-ordered unique identifier.

    Each identifier is comprised of 42 upper bits of timestamp representing the
    number of milliseconds that have elapsed since 2014-01-01T00:00:00+00:00
    (the epoch).  The remaining bits are a random nonce to prevent collisions
    between identifiers generated independently in the same millisecond.

    Args:
        epoch_timestamp: A integer value of the number of milliseconds since the
            epoch.  Use this to create a snowfloke for a specific time instead
            of the current time.

    Returns:
        A new snowflake identifier as an integer.

    Raises:
        ValueError: The given epoch timestamp is greater than 42 bits wide.
    """
    if epoch_timestamp:
        if epoch_timestamp.bit_length() > TIMESTAMP_LENGTH:
            raise ValueError("timestamp value is too large")
        ms = epoch_timestamp
    else:
        ms = make_epoch_timestamp()

    nonce = secrets.randbits(NONCE_LENGTH)

    return (ms << NONCE_LENGTH) + nonce


def parse(value):
    """
    Parse the given value and return its components.

    Args:
        value: a snowflake integer

    Returns:
        (timestamp integer, nonce as integer)

    Raises:
        ValueError: The value is 0 or negative
    """
    if not value or 0 > value:
        raise ValueError("value must be a positive integer")

    return (value >> NONCE_LENGTH, value & ((1 << NONCE_LENGTH) - 1))


def to_datetime(value):
    """
    Returns a snowflake with the timestamp component set to the given datetime
    object.

    Args:
        value: a snowflake integer

    Returns:
        An instance of `datetime.datetime` in the UTC timezone.
    """
    ms, _ = parse(value)
    delta = timedelta(milliseconds=ms)

    return datetime.fromtimestamp(EPOCH, tz=timezone.utc) + delta


def from_datetime(value):
    """
    Convert the given datetime value to a snowflake identifier.

    Args:
        value: an instance of datetime.datetime

    Returns:
        A snowflake integer

    Raises:
        ValueError: The given value is not using the UTC time zone.
    """
    if not value.tzinfo or value.tzinfo != timezone.utc:
        raise ValueError("value must use UTC time zone")
    posix_ts = int(value.timestamp())

    return generate(make_epoch_timestamp(posix_ts))


def to_base36(value, hyphenate=False):
    """
    Returns then given integer encoded in Base36.

    Args:
        value: An integer
        hyphenate: If true, add hypens between each span of four characters.
    """
    result = _encode(value, 36, BASE36_ALPHABET)
    if result and hyphenate:
        result = '-'.join([result[i:i + 4] for i in range(0, len(result), 4)])

    return result or BASE36_ALPHABET[0]


def from_base36(value):
    """
    Returns the decoded value of the given Base36 encoded string as an integer.
    """
    value = value.replace('-', '').lower()

    return int(value, 36)


def to_base57(value):
    """
    Returns then given integer encoded in Base57.

    The alphabet used for Base57 is the same as for Base62 but excludes:
    - Lower-case "L"
    - Capital "I"
    - Capital letter "O"
    - Capital *and* lower-case "U" (to prevent accidental profanity)
    """
    return _encode(value, 57, BASE57_ALPHABET) or BASE57_ALPHABET[0]


def from_base57(value):
    """
    Returns the decoded value of the given Base57 encoded string as an integer.
    """
    return _decode(value, 57, BASE57_ALPHABET)


def to_base62(value):
    """
    Returns the given integer encoded in Base62.

    The alphabet use for Base62 is:
        ASCII digits + ASCII uppercase letters + ASCII lowercase letters
    """
    return _encode(value, 62, BASE62_ALPHABET) or BASE62_ALPHABET[0]


def from_base62(value):
    """
    Returns the decoded value of the given Base62 encoded string as an integer.
    """
    return _decode(value, 62, BASE62_ALPHABET)


def to_base64(value):
    """
    Returns the given integer encoded in a URL-safe variation of Base64.

    Before encoding the value is packed in a particular way to reduce the size
    of the resulting encoded form.  Therefore, resuts from this function can
    only be decoded using the function `from_base64` in this package.
    """
    upper = value >> 32 if value > 0xFFFFFFFF else 0
    lower = value & 0xFFFFFFFF
    value = struct.pack('>LL', upper, lower)

    # drop leading zeros from packed binary string
    for i, c in enumerate(value):
        if c != 0:
            break

    value = base64.urlsafe_b64encode(value[i:])

    # drop trailing base64 padding characters from encoded string
    for i, c in enumerate(reversed(value)):
        if c != ord('='):
            break

    return value[:len(value)-i].decode('ascii')


def from_base64(value):
    """
    Returns the decoded value of the given encoded string as an integer.

    This function assumes the given value was encoded using the function
    `to_base64` in this package.  Providing any other input will result in
    incorrect values.
    """
    # append base64 padding characters to encoded string
    if len(value) % 4:
        value += ("=" * (4 - (len(value) % 4)))

    value = base64.urlsafe_b64decode(value)

    # prepend leading zeros to packed binary string
    if len(value) < 8:
        value = (b"\x00" * (8 - len(value))) + value

    upper, lower = struct.unpack(">LL", value)

    return int((upper << 32) | lower)


def lower_bound_for_datetime(value):
    """
    Returns a snowflake with the timestamp component set to the given datetime
    object.  Unlike `to_datetime` the result will have a zero value for its
    nonce.

    This is useful when querying for the occurence of snowflake identifiers that
    were created *after* a specific date and time.

    Args:
        value: an instance of `datetime.datetime` in the UTC timezone.

    Returns:
        A snowflake integer

    Raises:
        ValueError: The given value is not using the UTC time zone.
    """
    if not value.tzinfo or value.tzinfo != timezone.utc:
        raise ValueError("value must have a UTC time zone")
    posix_ts = int(value.timestamp())
    if EPOCH > posix_ts:
        raise ValueError("value must on or after the epoch")

    return make_epoch_timestamp(posix_ts) << NONCE_LENGTH


def upper_bound_for_datetime(value):
    """
    Returns a snowflake with the timestamp component set to the given datetime
    object.  Unlike `to_datetime` the result will have its nonce set to the
    maximum possible value.

    This is useful when querying for the occurence of snowflake identifiers that
    were created *before* a specific date and time.

    Args:
        value: an instance of `datetime.datetime` in the UTC timezone.

    Returns:
        A snowflake integer

    Raises:
        ValueError: The given value is not using the UTC time zone.
    """
    return lower_bound_for_datetime(value) + NONCE_MAX


def make_epoch_timestamp(posix_timestamp=None):
    """
    Returns the number of milliseconds that have elapsed since the custom epoch.

    Args:
        posix_timestamp: A decimal value of seconds/microseconds since the POSIX
            epoch, as returned from `time.time()`.

    Returns:
        The number of milliseconds that have elapsed since the custom epoch
        (2014-01-01T00:00:00+00:00).
    """
    if posix_timestamp and EPOCH > posix_timestamp:
        raise ValueError("value must on or after the epoch")
    if posix_timestamp is None:
        posix_timestamp = time.time()

    return int(round(posix_timestamp * 1000)) - (EPOCH * 1000)


def _encode(value, base, alphabet):
    result = ''
    while value:
        value, rem = divmod(value, base)
        result = alphabet[rem] + result

    return result


def _decode(value, base, alphabet):
    length = len(value)
    result = 0
    for i, d in enumerate(value):
        result += alphabet.index(d) * base ** (length - (i + 1))

    return result
    
