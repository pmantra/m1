import setuptools

with open("VERSION.txt", "r") as f:
    version = f.read().strip()

setuptools.setup(
    name="snowflake",
    version=version,
    author="Kevin Birch",
    author_email="kmb@mavenclinic.com",
    description="64-bit k-ordered unique ids for distributed systems",
    url="https://gitlab.mvnctl.net/maven/snowflake",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
    ],
)
